﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MilitaryElite.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
