﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Models.Animals.Contacts
{
    public interface ISoundProducable
    {
        string ProduceSound();
    }
}
